# twitter-sentimentsR
